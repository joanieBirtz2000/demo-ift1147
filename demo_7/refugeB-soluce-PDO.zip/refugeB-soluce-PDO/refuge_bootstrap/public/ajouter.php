<?php
require_once __DIR__ . '/../lib/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php?err=' . urlencode('Méthode invalide.'));
    exit;
}

$nom     = trim($_POST['nom'] ?? '');
$espece  = trim($_POST['espece'] ?? '');
$age_raw = trim($_POST['age'] ?? '');
$arr_raw = trim($_POST['arrivee'] ?? '');

// Validation identique
if ($nom === '' || $espece === '' || $age_raw === '' || $arr_raw === '') {
    header('Location: index.php?err=' . urlencode('Tous les champs sont requis.'));
    exit;
}
if (!ctype_digit($age_raw)) {
    header('Location: index.php?err=' . urlencode('Âge invalide.'));
    exit;
}

$age_i = (int)$age_raw;
$arrivee = $arr_raw;

try {
    $pdo = db();
    $stmt = $pdo->prepare(
        'INSERT INTO animaux (nom, espece, age, arrivee) VALUES (:nom, :espece, :age, :arrivee)'
    );
    
    $stmt->bindValue(':nom', $nom, PDO::PARAM_STR);
    $stmt->bindValue(':espece', $espece, PDO::PARAM_STR);
    $stmt->bindValue(':age', $age_i, PDO::PARAM_INT);
    $stmt->bindValue(':arrivee', $arrivee, PDO::PARAM_STR);
    
    $stmt->execute();

    header('Location: index.php?ok=1');
    exit;
} catch (PDOException $e) {
    header('Location: index.php?err=' . urlencode('Erreur base de données: ' . $e->getMessage()));
    exit;
}
?>