<?php
// refuge_bootstrap/lib/db.php
require_once __DIR__ . '/../config.php';


function db() {
    try {
        // Création de l'objet PDO pour la connexion à MySQL
        $pdo = new PDO(
            "mysql:host=" . DB_HOST .     // Hôte du serveur MySQL (ex: localhost)
            ";dbname=" . DB_NAME .        // Nom de la base de données
            ";charset=utf8mb4",           // Encodage des caractères (support Unicode complet)
            
            DB_USER,                      // Nom d'utilisateur MySQL
            DB_PASS,                      // Mot de passe MySQL
            
            // Tableau d'options pour configurer le comportement de PDO
            [
                // Active le mode exception pour les erreurs SQL
                //Les erreurs lancent des PDOException au lieu de retourner false
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                
                // Définit le mode de récupération par défaut des résultats
                // Retourne les lignes sous forme de tableau associatif ['colonne' => 'valeur']
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ]
        );
        
        // Retourne l'objet PDO
        return $pdo;
        
    } catch (PDOException $e) {
        // En cas d'erreur de connexion, affiche un message et arrête l'exécution
        die("Erreur de connexion : " . $e->getMessage());
    }
}

?>