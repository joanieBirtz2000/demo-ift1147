<?php
// refuge_bootstrap/lib/animaux.php
require_once __DIR__ . '/db.php';

function get_animaux() {
    $pdo = db();
    $sql = 'SELECT id, nom, espece, age, arrivee, created_at
            FROM animaux
            ORDER BY id DESC';
    
    $stmt = $pdo->query($sql);
    return $stmt->fetchAll();
}

function get_animal_by_id(int $id) {
    $pdo = db();

    $stmt = $pdo->prepare(
        'SELECT id, nom, espece, age, arrivee, created_at
         FROM animaux
         WHERE id = :id'
    );
    
    
    $stmt->bindValue(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
    
    return $stmt->fetch() ?: null;
}

// Version avec paramètres positionnels (alternative)
function get_animal_by_id_simple(int $id) {
    $pdo = db();

    $stmt = $pdo->prepare(
        'SELECT id, nom, espece, age, arrivee, created_at
         FROM animaux
         WHERE id = ?'
    );
    
    
    $stmt->bindValue(1, $id, PDO::PARAM_INT);
    $stmt->execute();
    
    return $stmt->fetch() ?: null;
}
?>