<?php
// refuge_bootstrap/config.php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');  // XAMPP: root
define('DB_PASS', '');      // XAMPP: vide | MAMP: root
define('DB_NAME', 'refuge_demo');
?>
